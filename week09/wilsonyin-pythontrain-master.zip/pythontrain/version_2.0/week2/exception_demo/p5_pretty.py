import pretty_errors
def foo():
    1/0

foo()

# pip install pretty_errors
# 美化异常输出