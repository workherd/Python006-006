1/0
# 发生异常后面的程序不再执行
print('never see me')


